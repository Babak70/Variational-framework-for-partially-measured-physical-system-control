1. Please download the content of file "dataset" and put them in directory "data\dataset"

2. Please download the content of file "dataset-iteration" and put them in both directories "dataset-iteration\0-3ed-original" and "dataset-iteration\0-3ed"

3. Please download file "training_checkpoints-fwd-main" and put it in in the "fw-model-vae" folder

4. Basic python libraries as well as Tensorflow 2.1., keras, sklearn and scipy are required.

5. Run main.py

