1- Please put transmit.mat in the "./fw-model-vae-iteration_fiber\fiber10_matlab" directory

2- Please download the content of file "0-3ed-original" and put all of them in both directories "data\dataset-iteration-fiber\0-3ed-original" and "data\dataset-iteration-fiber\0-3ed"

3- Matlab API must be installed on python. Please make sure matlab and python versions are compatible. The python version used is p 3.7.10

4- Basic python libraries, tensorflow 2.1, and keras, sklearn, scipy are required.

5- Run main.py